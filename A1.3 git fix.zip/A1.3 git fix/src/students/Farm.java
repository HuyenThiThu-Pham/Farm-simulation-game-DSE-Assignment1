package students;
import java.util.Scanner;

import java.util.List;
import students.items.*;

public class Farm {
	private Field field; // Field object to represent the farm field
    private double balance; // Player's balance
    private Scanner scanner; // Scanner object to read user input
    private boolean hasFarmTool; // Flag to track if the player has the harvesting tool
	
    // Constructor to initialize the Farm object
	public Farm(int fieldWidth, int fieldHeight, int startingFunds)
	{
		if (fieldWidth < 1 || fieldWidth > 10 || fieldHeight < 1 || fieldHeight > 10) {
	        System.err.println("Field dimensions must be between 1x1 and 10x10.");
	        System.err.println("Initializing with default dimensions (10x5).");
	        fieldWidth = 10;
	        fieldHeight = 5;
        }
		this.field = new Field(fieldWidth, fieldHeight); // Create a new Field object with given dimensions
        this.balance = startingFunds; // Initialize the player's balance
        this.scanner = new Scanner(System.in); // Initialize the scanner to read user input
        this.hasFarmTool = false; // Initially, the player doesn't have the harvesting tool
	}
	
	// Method to run the farm simulation
	public void run()
	{
		// Loop until the player decides to quit
        while (true) {
        	
            // Display the current state of the field and player's balance
            System.out.println(field);
            System.out.println("\nBank balance: $" + balance + "\n");
         
            
            System.out.println("Enter your next action:");
            System.out.println("  t x y: till");
            System.out.println("  h x y: harvest manually");
            System.out.println("  p x y: plant");
            System.out.println("  c: use FarmTool to harvest");
            System.out.println("  s: field summary");
            System.out.println("  w: wait");
            System.out.println("  q: quit");

            String action = scanner.nextLine(); // Read user input for the next action
            String[] parts = action.split(" "); // Split the input into parts

            
            // Check if the user wants to quit
            if (parts[0].equals("q")) {
                System.out.println("Quitting the game...See you next time!");
                break;
            }

            try {
            	// Validate user input and perform the action based on the command
            	if (parts[0].equals("t") || parts[0].equals("h") || parts[0].equals("p")) {
            	    if (parts.length != 3) {
            	        throw new IllegalArgumentException("Invalid input format. Please enter three space-separated values.");
            	    }
            	    int x = Integer.parseInt(parts[1]);
            	    int y = Integer.parseInt(parts[2]);

            	    if (x < 1 || x > field.getWidth() || y < 1 || y > field.getHeight()) {
            	        throw new IllegalArgumentException("Invalid location. Please enter coordinates within the field boundaries.");
            	    }
            	    performAction(parts[0].charAt(0), x-1, y-1); // correct location
            	    // Update ages of items in the field
                    field.tick();
            	} else if (parts[0].equals("c")) {
            		// Harvest the entire farm if the player has a farm tool
                    if (hasFarmTool()) {
                        
                        List<Food> harvestedFoods = field.harvestFarm(farmTool); // Perform harvest with the FarmTool
                        for (Food food : harvestedFoods) {
                            System.out.println("Sold '" + food + "' for $" + food.getValue());
                            balance += food.getValue(); // Add the value of harvested food to the balance
                        }
                    } else {
                        System.out.println("You need a Farm Tool to harvest the entire farm.");
                        // Check if the player can buy a Farm Tool
                        buyFarmTool();
                    }            		
            	    
            	} else if (parts[0].equals("s")) {
            	    System.out.println(field.getSummary()); // Print a summary of the field
            	} else if (parts[0].equals("w")) {
            	    field.tick(); // Wait, allowing items on the field to age
            	    System.out.println("You choose to wait for Food growing."); // Print a summary of the field
            	} else {
            	    System.out.println("Invalid command. Please try again.");
            	}
            } catch (NumberFormatException e) {
                System.out.println("Invalid input format. Please enter valid numbers.");
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    
    }
	
	
	/**
	 * Checks if the player has sufficient funds to buy a Farm Tool and prompts them if necessary.
	 * If the player has enough funds and doesn't already have a Farm Tool, prompts the player
	 * to buy the tool and deducts the cost from their balance.
	 * and sets {@code hasFarmTool} to true.
	 * @throws IllegalStateException if the balance is negative.
	 */
	private void buyFarmTool() {
	    int toolCost = 5; // Cost of the Farm Tool
	    
	    if (balance >= toolCost && !hasFarmTool()) {
	        
	        System.out.println("Do you want to buy a Farm Tool to help you efficiently harvest?. A Farm Tool costs $" + toolCost + ". (y/n)");
	        String input = scanner.nextLine().trim().toLowerCase();
	        // Validate user input
	        while (!input.equals("y") && !input.equals("n")) {
	            System.out.println("Invalid input. Please enter 'y' or 'n'.");
	            input = scanner.nextLine().trim().toLowerCase();
	        }
	        if (input.equals("y")) {
                balance -= toolCost;
                // Set hasFarmTool to true
                hasFarmTool = true;
                System.out.println("You bought a Farm Tool for $" + toolCost);
            } else {
                System.out.println("You decided not to buy a Farm Tool.");
            }
	                
	    } else {
	        System.out.println("You either don't have enough funds to buy a Farm Tool or already have one.");
	    }
	}
	

    // Method to perform the specified action
	/**
	 * Performs the specified action on the farm field based on the given command and coordinates. 
	 * @param action The action command to be performed ('t' for till, 'h' for harvest manually, 'p' for plant).	
	 * The harvest is performed manually at the specified location.
	 * @param x The x-coordinate of the location where the action is performed.
	 * @param y The y-coordinate of the location where the action is performed.
	 */
    private void performAction(char action, int x, int y) {
    	// Perform action based on the command
    	if (action == 't') {
    	    field.till(x, y); // Till the soil at the specified location
    	} 
    	else if (action == 'h') {
    		
                Food harvestedFood = field.harvest(x, y); // Harvest food at the specified location without a tool
                if (harvestedFood != null) {
                    System.out.println("Sold '" + harvestedFood + "' for $" + harvestedFood.getValue());
                    balance += harvestedFood.getValue(); // Add the value of harvested food to the balance
                }
            }
                
    	else if (action == 'p') {
    	    System.out.println("Enter:");
    	    System.out.println(" - 'a' to buy an apple for $" + Apple.getCost());
    	    System.out.println(" - 'g' to buy grain for $" + Grain.getCost());
    	    String plantChoice = scanner.nextLine();
    	    if (plantChoice.equals("a")) {
    	        if (balance >= Apple.getCost()) {
    	        	Item item = field.get(x, y); // Get the item at the specified location
    	            if (!(item instanceof Soil)) {
    	                System.out.println("You can only plant in soil.");
    	                return; // End the turn without further action
    	            }
    	            field.plant(x, y, new Apple()); // Plant an apple at the specified location
    	            balance -= Apple.getCost(); // Deduct the cost of the apple from the balance
    	        } else {
    	            System.out.println("You don't have enough funds to buy an apple.");
    	            return; // End the turn without further action
    	        }
    	    } 
    	    else if (plantChoice.equals("g")) {
    	        if (balance >= Grain.getCost()) {
    	        	Item item = field.get(x, y); // Get the item at the specified location
    	            if (!(item instanceof Soil)) {
    	                System.out.println("You can only plant in soil.");
    	                return; // End the turn without further action
    	            }
    	            field.plant(x, y, new Grain()); // Plant grain at the specified location
    	            balance -= Grain.getCost(); // Deduct the cost of the grain from the balance
    	        } 
    	        else {
    	            System.out.println("You don't have enough funds to buy grain.");
    	            return; // End the turn without further action
    	        }
    	    } 
    	    else {
    	        System.out.println("Invalid input. Please try again.");
    	    }
    	} 
    	else {
    	    System.out.println("Invalid command. Please try again.");
    	}
    }
    
    // Method to check if the player has the Farm Tool 
	public boolean hasFarmTool() {
		
		return hasFarmTool;
	}
	
	FarmTool farmTool = new FarmTool(5);
}
