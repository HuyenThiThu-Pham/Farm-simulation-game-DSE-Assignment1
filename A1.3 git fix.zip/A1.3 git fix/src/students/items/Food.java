package students.items;

public abstract class Food extends Item {
	
    public Food(int maturationAge, int deathAge, double monetaryValue) {
        super(maturationAge, deathAge, monetaryValue);
    }

    @Override
    public abstract double getValue(); //specific implementation in subclasses
}
