package students.items;

public class FarmTool extends Tool {
	 
  public FarmTool(int cost) {
      super(cost);
  }

}