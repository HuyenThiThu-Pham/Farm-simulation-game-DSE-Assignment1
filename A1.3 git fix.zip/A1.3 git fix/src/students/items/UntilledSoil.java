package students.items;

public class UntilledSoil extends Item {
    private static int untilledSoilCount = 0;

    public UntilledSoil() {
        super(Integer.MAX_VALUE, Integer.MAX_VALUE, -1); // Infinite maturation and death age, value = -1
        untilledSoilCount++;
    }

    public static int getGenerationCount() {
        return untilledSoilCount;
    }

    @Override
    public double getValue() {
        return -1.0; // Value is always -1
    }

    @Override
    public String toString() {
        return "/"; // Represented as "/"
    }
}
