package students.items;

public class Soil extends Item {
    private static int soilCount = 0;

    public Soil() {
        super(Integer.MAX_VALUE, Integer.MAX_VALUE, 0.0); // Infinite maturation and death age, value = 0
        soilCount++;
    }

    public static int getGenerationCount() {
        return soilCount;
    }

    @Override
    public double getValue() {
        return 0; // Value is always 0
    }

    @Override
    public String toString() {
        return "."; // Represented as "."
    }
}

