package students.items;

public class Weed extends Item {
    private static int weedCount = 0;

    public Weed() {
        super(Integer.MAX_VALUE, Integer.MAX_VALUE, -1.0); // Infinite maturation and death age, value = -1
        weedCount++;
    }

    public static int getGenerationCount() {
        return weedCount;
    }

    @Override
    public double getValue() {
        return -1; // Value is always -1
    }

    @Override
    public String toString() {
        return "#"; // Represented as "#"
    }
}

