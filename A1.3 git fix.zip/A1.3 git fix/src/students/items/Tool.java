package students.items;

//Tool class representing a generic harvesting tool
public abstract class Tool {
 private int cost;

 public Tool(int cost) {
     this.cost = cost;
 }

 public int getCost() {
     return cost;
 }

}


